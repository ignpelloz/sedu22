#include "mbed.h"

PwmOut servo(D3);
AnalogIn myldr(A0);

float umbral = 0.3;

void ldrToServo(void){

    float ldrVal = myldr.read();

    printf("Lectura LDR = %f ", ldrVal);
    
    if (ldrVal > umbral){
        printf("(Servo max)\n\r");
        servo.pulsewidth_us(2600);
    }else {
        printf("(Servo min)\n\r");
        servo.pulsewidth_us(350);
    }
    wait(0.5);
}

int main(){
   
   servo.period_us(20000);
   
   while (1) {
        ldrToServo();
    }
}