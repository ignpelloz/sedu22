#include "mbed.h"

// Fuente: https://os.mbed.com/teams/Seeed/code/MPU6050/
#include "MPU6050.h"
 
//Ratios de conversion 
#define A_R 16384.0
#define G_R 131.0

//Radianes a grados 180/PI 
#define RAD_TO_DEG 57.295779 

I2C    i2c(I2C_SDA, I2C_SCL);
MPU6050 mpu(D14, D15);

//La MPU-6050 da los valores en enteros de 16 bits. Valores sin refinar:
int16_t AcX, AcY, AcZ, GyX, GyY, GyZ;

//Angulos 
float Acc[2];
float Gy[2];
float Angle[2];
 
int main()
{
    printf("MPU6050 testConnection \n");
    bool mpu6050TestResult = mpu.testConnection();
    if(mpu6050TestResult) {
        printf("MPU6050 testConnection passed \n");
    } else {
        printf("MPU6050 testConnection failed \n");
    }
   
    while(1) {
        
        //Leer los valores del Acelerometro de la IMU
        AcX = mpu.getAcceleroRawX();
        AcY = mpu.getAcceleroRawY();
        AcZ = mpu.getAcceleroRawZ();
        
        //A partir de los valores del acelerometro, se calculan los angulos Y, X respectivanente, con la formula de la tangente.
        Acc[1] = atan(-1*(AcX/A_R)/sqrt(pow((AcY/A_R),2) + pow((AcZ/A_R),2)))*RAD_TO_DEG;
        Acc[0] = atan((AcY/A_R)/sqrt(pow((AcX/A_R),2) + pow((AcZ/A_R),2)))*RAD_TO_DEG;
        
        //Leer los valores del Giroscopio
        GyX = mpu.getGyroRawX();
        GyY = mpu.getGyroRawY();
        GyZ = mpu.getGyroRawZ();
        
        //Calculo del angulo del Giroscopio
        Gy[0] = GyX/G_R;
        Gy[1] = GyY/G_R;

        //aplicar el Filtro Complenentario
        Angle[0] = 0.98 *(Angle[0]+Gy[0]*0.010) + 0.02*Acc[0];
        Angle[1] = 0.98 *(Angle[1]+Gy[1]*0.010) + 0.02*Acc[1];
        
        //Mostrar los valores por consola
        //printf("Angle X: %f \n\r", Angle[0]); 
        //printf("Angle Y: %f \n\r", Angle[1]); 
        //printf("-------------------\n\r");
        printf("Angle X -> %f  /  %f <- Angle Y\n\r", Angle[0],Angle[1]); 
        
        //Lecturas de Acelerometro y Giroscopio
        //printf("%d   %d   %d  /  %d   %d   %d\n\r",AcX, AcY, AcZ, GyX, GyY, GyZ);
        
        // Delay en segundos
        wait(0.1);
    }
}