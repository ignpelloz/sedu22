
void  CreateJoyFlags(void);
void CreateJoyTask(void);
uint8_t waitForKey(uint8_t key, uint32_t timeout);
void SetFlagKey(uint8_t key);
