void Init_Joy(void);

uint8_t Read_Joy (void);
