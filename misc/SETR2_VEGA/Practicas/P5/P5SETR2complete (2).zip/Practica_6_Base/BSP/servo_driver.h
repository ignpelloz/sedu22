void Init_Servo_PWM(void);

void setServoPos(uint16_t grados);
