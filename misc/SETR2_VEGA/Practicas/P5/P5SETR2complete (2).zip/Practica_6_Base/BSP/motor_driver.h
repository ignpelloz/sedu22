void Init_Motor_PWM(void);

void setMotorSpeed(int8_t speed);
