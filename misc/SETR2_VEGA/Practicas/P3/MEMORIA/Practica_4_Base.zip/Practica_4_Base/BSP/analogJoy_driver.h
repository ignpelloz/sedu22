
void Init_AnalogJoy(void);
uint16_t getAnalogJoy(uint8_t axxis);
